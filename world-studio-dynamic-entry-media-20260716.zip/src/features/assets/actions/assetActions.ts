import { getAssetKind, MAX_ASSET_BYTES } from "../assetModel";
import { removeAssetFile, saveAssetFile, saveAssetThumbnail } from "../assetStorage";
import { useAssetStore } from "../stores/useAssetStore";
import type { AssetRecord } from "../types";
import { useEntryStore } from "../../entries/stores/useEntryStore";

function createAssetId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? `asset-${crypto.randomUUID()}`
    : `asset-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

async function createImageThumbnail(file: File) {
  if (!file.type.startsWith("image/")) return null;
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 640 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", 0.82));
}

export async function addAssetFile(file: File) {
  if (file.size > MAX_ASSET_BYTES) {
    throw new Error("asset-too-large");
  }

  const now = new Date().toISOString();
  const asset: AssetRecord = {
    id: createAssetId(),
    name: file.name,
    mediaType: file.type || "application/octet-stream",
    kind: getAssetKind(file.type),
    size: file.size,
    tags: [],
    createdAt: now,
    updatedAt: now,
  };

  await saveAssetFile(asset.id, file);
  try {
    const thumbnail = await createImageThumbnail(file);
    if (thumbnail) await saveAssetThumbnail(asset.id, thumbnail);
  } catch {
    // Unsupported formats still keep their original file and remain usable.
  }
  useAssetStore.getState().addAsset(asset);
  return asset;
}

export async function deleteAssetFile(assetId: string) {
  await removeAssetFile(assetId);
  useEntryStore.setState((state) => ({
    entries: state.entries.map((entry) => {
      const media = entry.media;
      if (!media) return entry;
      const nextMedia = {
        ...media,
        primaryAssetId: media.primaryAssetId === assetId ? undefined : media.primaryAssetId,
        bannerAssetId: media.bannerAssetId === assetId ? undefined : media.bannerAssetId,
        galleryAssetIds: media.galleryAssetIds?.filter((id) => id !== assetId),
      };
      return { ...entry, media: nextMedia };
    }),
  }));
  useAssetStore.getState().deleteAsset(assetId);
}
