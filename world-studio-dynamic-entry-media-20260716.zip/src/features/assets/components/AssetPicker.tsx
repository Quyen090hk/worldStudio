import { ImagePlus, Search, Upload, X } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { useI18n } from "../../../shared/i18n";
import { addAssetFile } from "../actions/assetActions";
import { useAssetStore } from "../stores/useAssetStore";
import { AssetThumbnail } from "./AssetThumbnail";

export function AssetPicker({ open, multiple = false, selectedIds = [], onSelect, onClose }: { open: boolean; multiple?: boolean; selectedIds?: string[]; onSelect: (ids: string[]) => void; onClose: () => void }) {
  const { t } = useI18n();
  const assets = useAssetStore((state) => state.assets);
  const [query, setQuery] = useState("");
  const [selection, setSelection] = useState<string[]>(selectedIds);
  const inputRef = useRef<HTMLInputElement>(null);
  const images = useMemo(() => assets.filter((asset) => asset.kind === "image" && `${asset.name} ${asset.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase())), [assets, query]);
  if (!open) return null;

  async function upload(files: FileList | null) {
    if (!files) return;
    const created: string[] = [];
    for (const file of Array.from(files)) {
      if (!file.type.startsWith("image/")) continue;
      created.push((await addAssetFile(file)).id);
    }
    if (!created.length) return;
    if (multiple) setSelection((current) => [...new Set([...current, ...created])]);
    else { onSelect([created[0]]); onClose(); }
  }

  function choose(id: string) {
    if (!multiple) { onSelect([id]); onClose(); return; }
    setSelection((current) => current.includes(id) ? current.filter((value) => value !== id) : [...current, id]);
  }

  return <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section role="dialog" aria-modal="true" className="flex max-h-[82vh] w-full max-w-3xl flex-col overflow-hidden rounded-[1.5rem] border border-[var(--border-strong)] bg-[var(--surface-solid)] shadow-2xl">
      <header className="flex items-center gap-3 border-b border-[var(--border)] p-4"><ImagePlus size={18} className="text-[var(--accent)]" /><div className="min-w-0 flex-1"><h2 className="font-semibold">{t("assetPicker.title")}</h2><p className="text-xs text-[var(--text-faint)]">{t("assetPicker.help")}</p></div><button type="button" onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-[var(--surface-muted)]"><X size={17} /></button></header>
      <div className="flex gap-2 border-b border-[var(--border)] p-4"><label className="ws-input flex h-10 min-w-0 flex-1 items-center gap-2 rounded-xl px-3"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} className="min-w-0 flex-1 bg-transparent text-sm outline-none" placeholder={t("common.search")} /></label><input ref={inputRef} type="file" accept="image/*" multiple={multiple} className="hidden" onChange={(event) => void upload(event.target.files)} /><button type="button" onClick={() => inputRef.current?.click()} className="ws-button-secondary flex h-10 items-center gap-2 rounded-xl px-3 text-sm font-semibold"><Upload size={15} />{t("assetPicker.upload")}</button></div>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">{images.length ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">{images.map((asset) => { const selected = selection.includes(asset.id); return <button type="button" key={asset.id} onClick={() => choose(asset.id)} className={`overflow-hidden rounded-xl border text-left transition ${selected ? "border-[var(--accent)] ring-2 ring-[var(--accent-soft)]" : "border-[var(--border)] hover:border-[var(--border-strong)]"}`}><AssetThumbnail assetId={asset.id} alt={asset.name} className="aspect-[4/3] w-full" /><span className="block truncate px-2.5 py-2 text-xs font-medium">{asset.name}</span></button>; })}</div> : <button type="button" onClick={() => inputRef.current?.click()} className="flex min-h-48 w-full flex-col items-center justify-center rounded-xl border border-dashed border-[var(--border)] text-sm text-[var(--text-muted)]"><ImagePlus size={28} className="mb-3" />{t("assetPicker.empty")}</button>}</div>
      {multiple ? <footer className="flex items-center justify-between border-t border-[var(--border)] p-4"><span className="text-xs text-[var(--text-faint)]">{t("assetPicker.selected", { count: selection.length })}</span><button type="button" onClick={() => { onSelect(selection); onClose(); }} className="ws-button-primary h-10 rounded-full px-4 text-sm font-semibold">{t("common.confirm")}</button></footer> : null}
    </section>
  </div>;
}
