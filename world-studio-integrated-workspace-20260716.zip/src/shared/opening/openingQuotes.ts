import type { Locale } from "../i18n/types";

export type OpeningQuote = {
  text: string;
  source: string;
};

// Public-domain texts only. Translations are intentionally not mixed across
// locales so each quotation retains the rhythm of its original language.
const quotes: Record<Locale, OpeningQuote[]> = {
  "zh-CN": [
    { text: "天地有大美而不言。", source: "《庄子·知北游》" },
    { text: "云无心以出岫，鸟倦飞而知还。", source: "陶渊明《归去来兮辞》" },
    { text: "操千曲而后晓声，观千剑而后识器。", source: "刘勰《文心雕龙》" },
    { text: "山中何所有，岭上多白云。", source: "陶弘景《诏问山中何所有赋诗以答》" },
    { text: "行到水穷处，坐看云起时。", source: "王维《终南别业》" },
    { text: "海内存知己，天涯若比邻。", source: "王勃《送杜少府之任蜀州》" },
  ],
  "en-US": [
    { text: "The world was all before them.", source: "John Milton · Paradise Lost" },
    { text: "There is no charm equal to tenderness of heart.", source: "Jane Austen · Emma" },
    { text: "Forever is composed of nows.", source: "Emily Dickinson" },
    { text: "The imagination is not a state: it is the human existence itself.", source: "William Blake" },
    { text: "I had not lived enough in the world to know the value of a journal.", source: "Henry David Thoreau · Walden" },
    { text: "We know what we are, but know not what we may be.", source: "William Shakespeare · Hamlet" },
  ],
};

const selectedQuoteKey = "world-studio-selected-opening-quote";

export function getOpeningQuotes(locale: Locale) {
  return quotes[locale];
}

export function getOpeningLocale(): Locale {
  let stored: string | null = null;
  try {
    stored = localStorage.getItem("world-studio-locale");
  } catch {
    // Storage may be blocked in hardened/private browser contexts.
  }
  if (stored === "zh-CN" || stored === "en-US") return stored;
  return navigator.language.toLowerCase().startsWith("zh") ? "zh-CN" : "en-US";
}

export function getDailyOpeningQuote(locale: Locale, date = new Date()) {
  const day = Math.floor(
    Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()) /
      86_400_000,
  );
  const collection = quotes[locale];
  return collection[((day % collection.length) + collection.length) % collection.length];
}

export function getSelectedOpeningQuote(locale: Locale) {
  try {
    const stored = Number(localStorage.getItem(`${selectedQuoteKey}.${locale}`));
    if (Number.isInteger(stored) && stored >= 0 && stored < quotes[locale].length) {
      return { quote: quotes[locale][stored], index: stored };
    }
  } catch {
    // Preferences remain optional when browser storage is blocked.
  }
  const quote = getDailyOpeningQuote(locale);
  return { quote, index: quotes[locale].indexOf(quote) };
}

export function selectOpeningQuote(locale: Locale, index: number) {
  const normalized = ((index % quotes[locale].length) + quotes[locale].length) % quotes[locale].length;
  try {
    localStorage.setItem(`${selectedQuoteKey}.${locale}`, String(normalized));
  } catch {
    // The in-memory selection still works for the current render.
  }
  return { quote: quotes[locale][normalized], index: normalized };
}
