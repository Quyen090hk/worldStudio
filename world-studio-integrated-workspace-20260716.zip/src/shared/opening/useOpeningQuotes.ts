import { useCallback, useMemo, useState } from "react";
import { useI18n } from "../i18n";
import {
  getOpeningQuotes,
  getSelectedOpeningQuote,
  selectOpeningQuote,
} from "./openingQuotes";

const favoritesKey = "world-studio-favorite-quotes";

function readFavorites(locale: string) {
  try {
    const value = JSON.parse(localStorage.getItem(`${favoritesKey}.${locale}`) ?? "[]");
    return Array.isArray(value) ? value.filter(Number.isInteger) as number[] : [];
  } catch {
    return [];
  }
}

export function useOpeningQuotes() {
  const { locale } = useI18n();
  const collection = useMemo(() => getOpeningQuotes(locale), [locale]);
  const initial = useMemo(() => getSelectedOpeningQuote(locale), [locale]);
  const [indices, setIndices] = useState<Record<string, number>>(() => ({ [locale]: initial.index }));
  const [favoritesByLocale, setFavoritesByLocale] = useState<Record<string, number[]>>(() => ({ [locale]: readFavorites(locale) }));
  const index = indices[locale] ?? initial.index;
  const favorites = favoritesByLocale[locale] ?? readFavorites(locale);
  const safeIndex = ((index % collection.length) + collection.length) % collection.length;

  const choose = useCallback((nextIndex: number) => {
    const selected = selectOpeningQuote(locale, nextIndex);
    setIndices((current) => ({ ...current, [locale]: selected.index }));
  }, [locale]);

  const next = useCallback(() => choose(safeIndex + 1), [choose, safeIndex]);
  const previous = useCallback(() => choose(safeIndex - 1), [choose, safeIndex]);
  const toggleFavorite = useCallback(() => {
    setFavoritesByLocale((allFavorites) => {
      const current = allFavorites[locale] ?? readFavorites(locale);
      const nextValue = current.includes(safeIndex)
        ? current.filter((value) => value !== safeIndex)
        : [...current, safeIndex];
      try {
        localStorage.setItem(`${favoritesKey}.${locale}`, JSON.stringify(nextValue));
      } catch {
        // Favorites remain available for the current session.
      }
      return { ...allFavorites, [locale]: nextValue };
    });
  }, [locale, safeIndex]);

  return {
    quote: collection[safeIndex],
    index: safeIndex,
    total: collection.length,
    favorite: favorites.includes(safeIndex),
    favorites,
    collection,
    choose,
    next,
    previous,
    toggleFavorite,
  };
}
