import { describe, expect, it } from "vitest";
import { getDailyOpeningQuote } from "./openingQuotes";

describe("opening quotations", () => {
  it("keeps a quotation stable throughout the same UTC day", () => {
    const morning = getDailyOpeningQuote("zh-CN", new Date("2026-07-16T01:00:00Z"));
    const evening = getDailyOpeningQuote("zh-CN", new Date("2026-07-16T23:00:00Z"));
    expect(morning).toEqual(evening);
  });

  it("provides localized text and attribution", () => {
    for (const locale of ["zh-CN", "en-US"] as const) {
      const quote = getDailyOpeningQuote(locale, new Date("2026-07-16T12:00:00Z"));
      expect(quote.text.length).toBeGreaterThan(4);
      expect(quote.source.length).toBeGreaterThan(2);
    }
  });
});
