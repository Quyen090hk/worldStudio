import { Check, ChevronDown } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useI18n } from "../i18n";
import { moduleForPath, workspaceModules } from "../navigation/modules";
import { LanguageMenu } from "./LanguageMenu";

export function ModuleSwitcher() {
  const { t } = useI18n();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const current = moduleForPath(location.pathname);
  const CurrentIcon = current.icon;

  useEffect(() => {
    if (!open) return;
    const closeOutside = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const closeWithEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("mousedown", closeOutside);
    window.addEventListener("keydown", closeWithEscape);
    return () => {
      window.removeEventListener("mousedown", closeOutside);
      window.removeEventListener("keydown", closeWithEscape);
    };
  }, [open]);

  return (
    <div ref={rootRef} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="flex h-10 items-center gap-2 rounded-xl px-2.5 text-sm font-semibold text-[var(--text-muted)] transition hover:bg-[var(--surface-muted)] hover:text-[var(--text)]"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <CurrentIcon size={16} strokeWidth={1.7} />
        <span>{t(current.label)}</span>
        <ChevronDown size={14} className={`transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open ? (
        <div role="menu" className="ws-popover-enter absolute left-0 top-[calc(100%+.55rem)] z-50 grid w-[min(31rem,calc(100vw-2rem))] grid-cols-2 gap-1 rounded-2xl border border-[var(--border-strong)] bg-[var(--surface-raised)] p-2 shadow-2xl sm:grid-cols-3">
          {workspaceModules.map((item) => {
            const Icon = item.icon;
            const active = item.path === current.path;
            return (
              <button
                key={item.path}
                type="button"
                role="menuitemradio"
                aria-checked={active}
                onClick={() => {
                  navigate(item.path);
                  setOpen(false);
                }}
                className="flex items-center gap-2.5 rounded-xl px-3 py-3 text-left text-sm transition hover:bg-[var(--surface-muted)]"
              >
                <Icon size={17} className={active ? "text-[var(--accent)]" : "text-[var(--text-faint)]"} />
                <span className="min-w-0 flex-1 truncate font-semibold">{t(item.label)}</span>
                {active ? <Check size={14} className="text-[var(--accent)]" /> : null}
              </button>
            );
          })}
          <div className="col-span-2 border-t border-[var(--border)] pt-2 sm:hidden">
            <LanguageMenu compact />
          </div>
        </div>
      ) : null}
    </div>
  );
}
