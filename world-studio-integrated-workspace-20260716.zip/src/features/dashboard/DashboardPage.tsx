import { motion } from "motion/react";
import {
  ArrowRight,
  BookOpen,
  Boxes,
  GitBranch,
  Image,
  Map,
  Plus,
  Timer,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

import { DailyQuote } from "../../shared/components/DailyQuote";
import { MotionPage } from "../../shared/components/MotionPage";
import { useI18n } from "../../shared/i18n";
import { pressTap } from "../../shared/motion/presets";
import { useAssetStore } from "../assets/stores/useAssetStore";
import { useCanvasStore } from "../canvas/stores/useCanvasStore";
import { EntryTypeBadge } from "../entries/components/EntryTypeBadge";
import { useEntryStore } from "../entries/stores/useEntryStore";
import { formatEntryDate } from "../entries/utils/formatEntryDate";
import { useRelationshipStore } from "../graph/stores/useRelationshipStore";
import { useMapStore } from "../map/stores/useMapStore";
import { useTimelineStore } from "../timeline/stores/useTimelineStore";
import { useWorldStore } from "../world/stores/useWorldStore";

export function DashboardPage() {
  const entries = useEntryStore((state) => state.entries);
  const openCreateEntry = useEntryStore((state) => state.openCreateEntry);
  const markers = useMapStore((state) => state.markers);
  const relationships = useRelationshipStore((state) => state.relationships);
  const timelineItems = useTimelineStore((state) => state.items);
  const canvasCards = useCanvasStore((state) => state.cards);
  const assets = useAssetStore((state) => state.assets);
  const profile = useWorldStore((state) => state.profile);
  const navigate = useNavigate();
  const { t, locale } = useI18n();

  const recentEntries = [...entries]
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    .slice(0, 4);
  const latestEntry = recentEntries[0] ?? null;
  const modules = [
    { icon: BookOpen, label: t("nav.entries"), value: entries.length, detail: t("dashboard.entries"), path: "/entries" },
    { icon: Map, label: t("nav.map"), value: markers.length, detail: t("dashboard.mapMarkers"), path: "/map" },
    { icon: GitBranch, label: t("nav.graph"), value: relationships.length, detail: t("dashboard.relations"), path: "/graph" },
    { icon: Timer, label: t("nav.timeline"), value: timelineItems.length, detail: t("dashboard.timelineEvents"), path: "/timeline" },
    { icon: Boxes, label: t("nav.canvas"), value: canvasCards.length, detail: t("settings.canvasCards"), path: "/canvas" },
    { icon: Image, label: t("nav.assets"), value: assets.length, detail: t("settings.assets"), path: "/assets" },
  ];
  const incompleteEntries = entries.filter((entry) => !entry.content.trim()).length;
  const tasks = [
    incompleteEntries ? { text: t("dashboard.incompleteEntries", { count: incompleteEntries }), path: "/entries" } : null,
    !markers.length ? { text: t("dashboard.noMapMarkers"), path: "/map" } : null,
    !timelineItems.length ? { text: t("dashboard.noTimelineEvents"), path: "/timeline" } : null,
  ].filter((task): task is { text: string; path: string } => Boolean(task));

  return (
    <MotionPage className="space-y-12 pb-12 pt-4">
      <header className="grid items-end gap-8 border-b border-[var(--border)] pb-10 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="min-w-0">
          <p className="ws-eyebrow mb-3 truncate">{profile.name}</p>
          <h1 className="ws-page-title">{latestEntry ? t("dashboard.continueTitle") : t("dashboard.readyTitle")}</h1>
          <p className="ws-page-status">
            {latestEntry
              ? t("dashboard.resumeEntry", { title: latestEntry.title, date: formatEntryDate(latestEntry.updatedAt, locale) })
              : t("dashboard.readyDescription")}
          </p>
          <div className="mt-6 flex flex-wrap gap-2.5">
            {latestEntry ? (
              <motion.button type="button" whileTap={pressTap} onClick={() => navigate(`/entries/${latestEntry.id}`)} className="ws-button-primary flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold">
                <BookOpen size={16} />{t("dashboard.continueEntry")}
              </motion.button>
            ) : null}
            <button type="button" onClick={openCreateEntry} className="ws-button-secondary flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold"><Plus size={16} />{t("topbar.newEntry")}</button>
          </div>
        </div>
        <DailyQuote compact />
      </header>

      <section>
        <div className="mb-4 flex items-end justify-between gap-4">
          <div><p className="ws-eyebrow">{t("dashboard.exploreEyebrow")}</p><h2 className="ws-display mt-2 text-3xl font-semibold">{t("dashboard.exploreWorld")}</h2></div>
          <p className="hidden text-xs text-[var(--text-faint)] sm:block">{t("dashboard.moduleHint")}</p>
        </div>
        <div className="grid border-y border-[var(--border)] md:grid-cols-2">
          {modules.map((item, index) => {
            const Icon = item.icon;
            return <button type="button" key={item.path} onClick={() => navigate(item.path)} className={`group flex items-center gap-4 py-5 text-left transition hover:bg-[var(--surface-muted)] md:px-5 ${index > 0 ? "border-t border-[var(--border)]" : ""} ${index === 1 ? "md:border-t-0" : ""} ${index % 2 ? "md:border-l" : ""}`}>
              <Icon size={19} className="text-[var(--accent)]" />
              <span className="min-w-0 flex-1"><b className="block text-sm">{item.label}</b><small className="mt-1 block text-[var(--text-faint)]">{item.value} {item.detail}</small></span>
              <ArrowRight size={15} className="text-[var(--text-faint)] transition group-hover:translate-x-1 group-hover:text-[var(--text)]" />
            </button>;
          })}
        </div>
      </section>

      <div className="grid gap-10 lg:grid-cols-[minmax(0,1.5fr)_minmax(17rem,.7fr)]">
        <section>
          <div className="mb-4 flex items-center justify-between"><h2 className="ws-display text-3xl font-semibold">{t("dashboard.recentlyUpdated")}</h2><button type="button" onClick={() => navigate("/entries")} className="text-xs font-semibold text-[var(--text-muted)] hover:text-[var(--text)]">{t("common.browseArchive")}</button></div>
          {recentEntries.length ? <div className="divide-y divide-[var(--border)] border-y border-[var(--border)]">{recentEntries.map((entry) => <button type="button" key={entry.id} onClick={() => navigate(`/entries/${entry.id}`)} className="grid w-full gap-2 py-4 text-left transition hover:pl-2 sm:grid-cols-[7rem_minmax(0,1fr)_auto] sm:items-center sm:gap-4"><EntryTypeBadge type={entry.type} /><span className="min-w-0"><b className="block truncate text-sm">{entry.title}</b><small className="mt-1 block truncate text-[var(--text-faint)]">{entry.summary || t("common.noSummary")}</small></span><time className="text-xs text-[var(--text-faint)]">{formatEntryDate(entry.updatedAt, locale)}</time></button>)}</div> : <button type="button" onClick={openCreateEntry} className="w-full border-y border-dashed border-[var(--border)] py-12 text-sm text-[var(--text-muted)]">{t("dashboard.readyDescription")}</button>}
        </section>

        <aside>
          <p className="ws-eyebrow">{t("dashboard.nextSteps")}</p>
          <h2 className="ws-display mt-2 text-2xl font-semibold">{t("dashboard.keepBuilding")}</h2>
          <div className="mt-4 divide-y divide-[var(--border)] border-y border-[var(--border)]">
            {tasks.length ? tasks.map((task) => <button type="button" key={task.text} onClick={() => navigate(task.path)} className="group flex w-full items-center gap-3 py-4 text-left text-sm"><span className="min-w-0 flex-1 text-[var(--text-muted)] group-hover:text-[var(--text)]">{task.text}</span><ArrowRight size={14} className="text-[var(--text-faint)]" /></button>) : <p className="py-5 text-sm leading-6 text-[var(--text-muted)]">{t("dashboard.worldTakingShape")}</p>}
          </div>
        </aside>
      </div>
    </MotionPage>
  );
}
