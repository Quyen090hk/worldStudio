import { ChevronLeft, ChevronRight, Heart } from "lucide-react";
import { MotionPage } from "../../shared/components/MotionPage";
import { useI18n } from "../../shared/i18n";
import { useOpeningQuotes } from "../../shared/opening/useOpeningQuotes";

export function InspirationPage() {
  const { t } = useI18n();
  const { quote, index, total, previous, next, favorite, toggleFavorite, collection, choose, favorites } = useOpeningQuotes();
  return (
    <MotionPage className="mx-auto max-w-5xl py-6 sm:py-12">
      <header className="text-center">
        <p className="ws-eyebrow">{t("inspiration.eyebrow")}</p>
        <h1 className="ws-page-title mt-3">{t("inspiration.title")}</h1>
        <p className="ws-page-status mx-auto">{t("inspiration.description")}</p>
      </header>

      <section className="relative mt-10 flex min-h-[25rem] flex-col items-center justify-center border-y border-[var(--border)] px-6 py-16 text-center">
        <blockquote className="ws-display max-w-3xl text-3xl leading-relaxed text-[var(--text)] sm:text-5xl" style={{ viewTransitionName: "daily-quote" }}>{quote.text}</blockquote>
        <cite className="mt-7 text-sm not-italic text-[var(--text-faint)]">{quote.source}</cite>
        <div className="mt-10 flex items-center gap-3">
          <button type="button" onClick={previous} className="ws-button-secondary flex h-11 w-11 items-center justify-center rounded-full" aria-label={t("inspiration.previous")}><ChevronLeft size={18} /></button>
          <button type="button" onClick={toggleFavorite} className={`flex h-11 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition ${favorite ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent)]" : "border-[var(--border)] text-[var(--text-muted)] hover:bg-[var(--surface-muted)]"}`}><Heart size={16} fill={favorite ? "currentColor" : "none"} />{t("inspiration.favorite")}</button>
          <button type="button" onClick={next} className="ws-button-primary flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold">{t("inspiration.another")}<ChevronRight size={17} /></button>
        </div>
        <p className="mt-5 text-xs text-[var(--text-faint)]">{index + 1} / {total} · {t("inspiration.openingHint")}</p>
      </section>

      <section className="mt-10">
        <div className="mb-4 flex items-center justify-between"><h2 className="ws-display text-2xl font-semibold">{t("inspiration.collection")}</h2><span className="text-xs text-[var(--text-faint)]">{favorites.length} {t("inspiration.favorites")}</span></div>
        <div className="divide-y divide-[var(--border)] border-y border-[var(--border)]">
          {collection.map((item, itemIndex) => <button type="button" key={`${item.source}-${itemIndex}`} onClick={() => choose(itemIndex)} className="flex w-full items-center gap-4 py-4 text-left transition hover:pl-2"><span className="w-6 text-xs text-[var(--text-faint)]">{String(itemIndex + 1).padStart(2, "0")}</span><span className="min-w-0 flex-1"><b className="block truncate font-medium">{item.text}</b><small className="mt-1 block text-[var(--text-faint)]">{item.source}</small></span>{favorites.includes(itemIndex) ? <Heart size={14} fill="currentColor" className="text-[var(--accent)]" /> : null}</button>)}
        </div>
      </section>
    </MotionPage>
  );
}
